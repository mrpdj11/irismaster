<?php

require_once 'includes/load.php';


if (isset($_POST)) {
  $bin = $_POST['item_code'];
  // print_r_html($bin);

  $aisle_details = array();
  $all_aisle_location = $db->query('SELECT * FROM tb_bin_location_bac WHERE aisle = ? ORDER BY location_code ASC', $bin)->fetch_all();

  foreach ($all_aisle_location as $arr_key => $arr_det) {
    $get_inbound_detail = $db->query('SELECT * FROM tb_inbound where bin_location = ?', $arr_det['location_code'])->fetch_all();
    if (!empty($get_inbound_detail)) {
      foreach ($get_inbound_detail as $asar_key => $asar_val) {
        $aisle_details[] = $asar_val;
      }
    } else {
      $aisle_details[]['bin_location'] = $arr_det['location_code'];
    }
  }

  // print_r_html($aisle_details);

  $file_name = 'Daily Cycle Count.csv';
  header("Content-Description: File Transfer");
  header("Content-Disposition: attachment; filename=$file_name");
  header("Content-Type: text/csv;");

  $file = fopen('php://output', 'w');

  $header = array("Location",  "Item Code",  "Batch No",  "Qty(IN)", "Qty(OUT)", "Available(PCS)", "LPN",);

  fputcsv($file, $header);

  foreach ($aisle_details as $aisle_det => $aisle_val) {
    $data = array();
    if (array_key_exists('id', $aisle_val)) {
      $data = array($aisle_val['bin_location'],  $aisle_val['item_code'], $aisle_val['batch_no'], $aisle_val['qty_pcs'], $aisle_val['dispatch_qty'], $aisle_val['qty_pcs'] - $aisle_val['dispatch_qty'], $aisle_val['lpn']);
      fputcsv($file, $data);
    } else {
      $data = array($aisle_val['bin_location'], '', '', '', '', '', '');
      fputcsv($file, $data);
    }
  }

  fclose($file);
  exit;
}
